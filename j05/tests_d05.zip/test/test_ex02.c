#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "../ex02/ft_atoi.c"

int main() {
	assert(atoi("-2147483648") == ft_atoi("-2147483648"));
	assert(atoi("21") == ft_atoi("21"));
	assert(atoi("-21") == ft_atoi("-21"));
	assert(atoi("33") == ft_atoi("33"));
	assert(atoi("99") == ft_atoi("99"));
	assert(atoi("1000000") == ft_atoi("1000000"));
	assert(atoi("0") == ft_atoi("0"));
	assert(atoi("709551615") == ft_atoi("709551615"));
	assert(atoi("-12") == ft_atoi("-12"));
	assert(atoi("-12") == ft_atoi("-12"));
	assert(atoi("12") == ft_atoi("12"));
	assert(atoi("12") == ft_atoi("12"));
	assert(atoi("2147483647") == ft_atoi("2147483647"));
	assert(atoi("0") == ft_atoi("0"));
	assert(atoi("0") == ft_atoi("0"));
	assert(atoi("0") == ft_atoi("0"));
	assert(atoi("0") == ft_atoi("0"));
	assert(atoi("2") == ft_atoi("2"));
	assert(atoi("-2147483648") == ft_atoi("-2147483648"));
	assert(atoi("\r \n21") == ft_atoi("\r \n21"));
	assert(atoi("-21") == ft_atoi("-21"));
	assert(atoi("33") == ft_atoi("33"));
	assert(atoi("99") == ft_atoi("99"));
	assert(atoi("1000000") == ft_atoi("1000000"));
	assert(atoi("0") == ft_atoi("0"));
	assert(atoi("709551615") == ft_atoi("709551615"));
	assert(atoi("-12") == ft_atoi("-12"));
	assert(atoi("\t\r\n -12") == ft_atoi("\t\r\n -12"));
	assert(atoi("12") == ft_atoi("12"));
	assert(atoi("\f12") == ft_atoi("\f12"));
	assert(atoi("+2147483647") == ft_atoi("+2147483647"));
	assert(atoi(" 0") == ft_atoi(" 0"));
	assert(atoi("\v\v+0") == ft_atoi("\v\v+0"));
	assert(atoi("0") == ft_atoi("0"));
	assert(atoi("  \n0") == ft_atoi("  \n0"));
	assert(atoi("2") == ft_atoi("2"));
	assert(atoi("2654564645465465456") == ft_atoi("2654564645465465456"));
	assert(atoi("26545646454654654") == ft_atoi("26545646454654654"));
	assert(atoi("265456464546546545") == ft_atoi("265456464546546545"));
	assert(atoi("2654564645465465456") == ft_atoi("2654564645465465456"));
	assert(atoi("-2147483648") == ft_atoi("-2147483648"));
	assert(atoi("-21474836481") == ft_atoi("-21474836481"));
	assert(atoi("2147483647") == ft_atoi("2147483647"));
	assert(atoi("21474836471") == ft_atoi("21474836471"));
	assert(atoi("11afgh") == ft_atoi("11afgh"));
	return 0;
}
