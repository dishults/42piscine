#include <stdio.h>
#include <assert.h>
#include <memory.h>
#include "../ex06/ft_strcmp.c"

int main() {
	assert(strcmp("", "") == ft_strcmp("", ""));
	assert(strcmp("42", "42") == ft_strcmp("42", "42"));
	assert(strcmp("424", "42") == ft_strcmp("424", "42"));
	assert(strcmp("42", "424") == ft_strcmp("42", "424"));
	assert(strcmp("", "424") == ft_strcmp("", "424"));
	assert(strcmp("45", "") == ft_strcmp("45", ""));
	return 0;
}
