#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <memory.h>
#include "../ex11/ft_str_is_alpha.c"

int main() {
	assert(ft_str_is_alpha("asdAfsaFdf"));
	assert(ft_str_is_alpha("asdfsadf"));
	assert(ft_str_is_alpha(""));
	assert(ft_str_is_alpha("asdfs1adf") == 0);
	assert(ft_str_is_alpha("asdfs-1adf") == 0);
	return 0;
}
