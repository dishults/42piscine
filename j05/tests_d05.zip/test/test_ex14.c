#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <memory.h>
#include "../ex14/ft_str_is_uppercase.c"

int main() {
	assert(ft_str_is_uppercase("DSADAS"));
	assert(ft_str_is_uppercase("A"));
	assert(ft_str_is_uppercase(""));
	assert(ft_str_is_uppercase("D-") == 0);
	assert(ft_str_is_uppercase("d") == 0);
	return 0;
}
