#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <memory.h>
#include "../ex21/ft_atoi_base.c"

void ft_putchar(char c) {
	putc(c, stdout);
}

int main()
{
	printf("%d\n", ft_atoi_base("101", "01"));
	printf("%d\n", ft_atoi_base("101011100110", "01"));
	printf("%d\n", ft_atoi_base("-2147483648", "0123456789"));
	printf("%d\n", ft_atoi_base("-2147483648", "0123456789"));
	printf("%d\n", ft_atoi_base("101010", "01"));
	printf("%d\n", ft_atoi_base("101010", "10"));
	printf("%d\n", ft_atoi_base("2A", "0123456789ABCDEF"));
	printf("%d\n", ft_atoi_base("-2A", "0123456789ABCDEF"));
	ft_putchar('\n');
	return 0;
}