#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <memory.h>
#include "../ex12/ft_str_is_numeric.c"

int main() {
	assert(ft_str_is_numeric("51651"));
	assert(ft_str_is_numeric("15"));
	assert(ft_str_is_numeric(""));
	assert(ft_str_is_numeric("asdfs1adf") == 0);
	assert(ft_str_is_numeric("54564f") == 0);
	return 0;
}
