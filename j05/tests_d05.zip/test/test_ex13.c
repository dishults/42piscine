#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <memory.h>
#include "../ex13/ft_str_is_lowercase.c"

int main() {
	assert(ft_str_is_lowercase("ssdfsdf"));
	assert(ft_str_is_lowercase("s"));
	assert(ft_str_is_lowercase(""));
	assert(ft_str_is_lowercase("f-") == 0);
	assert(ft_str_is_lowercase("F") == 0);
	return 0;
}
