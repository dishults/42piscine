#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <memory.h>
#include "../ex22/ft_putstr_non_printable.c"

void ft_putchar(char c) {
	putc(c, stdout);
}

int main()
{
	ft_putstr_non_printable("Coucou\"tu vas bien ?");
	ft_putstr_non_printable("Coucou\ntu \rvas\t \0bien\f ?\v");
	return 0;
}
