#include <stdio.h>
#include <assert.h>
#include <memory.h>
#include "../ex07/ft_strncmp.c"

int main() {
	assert(strncmp("", "", 5) == ft_strncmp("", "", 5));
	assert(strncmp("42", "42", 1) == ft_strncmp("42", "42", 1));
	assert(strncmp("424", "42", 6) == ft_strncmp("424", "42", 6));
	assert(strncmp("42", "424", 1) == ft_strncmp("42", "424", 1));
	assert(strncmp("", "424", 2) == ft_strncmp("", "424", 2));
	assert(strncmp("45", "", 1) == ft_strncmp("45", "", 1));
	return 0;
}
