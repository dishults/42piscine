#include <stdio.h>
#include <memory.h>
#include "../ex08/ft_strupcase.c"


int main() {
	puts(ft_strupcase(strdup("salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un")));
	return 0;
}
