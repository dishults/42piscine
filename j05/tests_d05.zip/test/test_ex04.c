#include <stdio.h>
#include <assert.h>
#include <memory.h>
#include "../ex04/ft_strncpy.c"

void test_ft_strncpy(char *str, unsigned int n)
{
	char dest[255];
	char dest2[255];

	strncpy(dest, str, n);
	ft_strncpy(dest2, str, n);
	assert(strcmp(dest, str) == strcmp(dest2, str));

}

int main() {
	test_ft_strncpy("", 2);
	test_ft_strncpy("foobar", 3);
	test_ft_strncpy("cat", 2);
	test_ft_strncpy("catdsaf'd", 5);
	test_ft_strncpy("catdsaf'd    fsd", 55);
	return 0;
}
