#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <memory.h>
#include "../ex10/ft_strcapitalize.c"

int main() {
	char *ptr;
	ptr = strdup("salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un");
	printf("%s\n", ft_strcapitalize(ptr));
	return 0;
}
