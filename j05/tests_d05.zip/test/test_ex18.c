#include <stdio.h>
#include <assert.h>
#include <memory.h>
#include "../ex18/ft_strlcat.c"

void test_ft_strlcat(char *dest, char *src, unsigned int n)
{
	char *dest2 = strdup(dest);
	char *src2 = strdup(src);

	assert(strlcat(dest, src, n) == ft_strlcat(dest2, src2, n));
	printf("dests:'%zu' dest2s:'%d'\n", strlcat(dest, src, n), ft_strlcat(dest2, src2, n));
	printf("dest:'%s' dest2:'%s'\n", dest, dest2);
	assert(strcmp(dest, dest2) == 0);
}

int main() {
	test_ft_strlcat(strdup(""), "", 1);
	test_ft_strlcat(strdup("foobar"), "baz", 20);
	test_ft_strlcat(strdup("cat"), "me", 4);
	test_ft_strlcat(strdup("catdsafcbxcvbxcb"), "sdadfsd", 55);
	test_ft_strlcat(strdup("catdsaf'd    fsd"), "sdfg", 15);
	test_ft_strlcat(strdup("asdff"), "sdsdfsfg", 0);
	test_ft_strlcat(strdup("agfdgdgdgfdgd"), "sdsdfsfg", 2);
	test_ft_strlcat(strdup("agfdgdgdgfsdfsafggfddfhytfjxyjfdgd"), "sdsddytjghjghjytdjtyjghfsfg", 29);
	test_ft_strlcat(strdup("agfdgfdsafs√cxvxvdgdgfdgd"), "sdsdfsgdfhhgfg", 10);
	test_ft_strlcat(strdup("agfdgddsfdfdrtsgdgfdgd"), "sdsdrtregfrtfsfg", 25);
	test_ft_strlcat(strdup(""), "sdsdfsfg", 2);
	test_ft_strlcat(strdup("agfdgdgdgfdgd"), "", 2);
	return 0;
}
