#include <stdio.h>
#include <assert.h>
#include <memory.h>
#include "../ex16/ft_strcat.c"

void test_ft_strcat(char *dest, char *src)
{
	char *dest2 = dest;
	char *src2 = src;

	strcat(dest, src);
	ft_strcat(dest2, src2);
	assert(strcmp(dest, dest2));

}

int main() {
	test_ft_strcat("", "");
	test_ft_strcat("foobar", "baz");
	test_ft_strcat("cat", "me");
	test_ft_strcat("catdsaf'd", "sdadfsd");
	test_ft_strcat("catdsaf'd    fsd", "\r\r\r\r\r\r");
	return 0;
}
