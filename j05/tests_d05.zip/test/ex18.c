#include <stdio.h>
#include <string.h>
#include "../ex18/ft_strlcat.c"

void test(char *dest, char *src, unsigned int size)
{
	char ft_dest[100];
	int len;
	int ft_len;

	strcpy(ft_dest, dest);
	len = strlcat(dest, src, size);
	ft_len = ft_strlcat(ft_dest, src, size);
	printf("ft_strlcat(%s, %d) strlcat(%s, %d) : %d\n", ft_dest, ft_len, dest, len, strcmp(dest, ft_dest) == 0);
}

int main()
{
	char dest[50];

	strcpy(dest, "sa");
	test(dest, "lut", 5);

	strcpy(dest, "sal");
	test(dest, "ut.", 5);

	strcpy(dest, "sal");
	test(dest, "ut.", 3);

	strcpy(dest, "sal");
	test(dest, "ut.", 7);

	strcpy(dest, "sagfdsgdgfdsgdsgdl");
	test(dest, "ut.dfgfdsgdsgdgds", 60);

	strcpy(dest, "sagfdsdfdsafssgdgfdsgdsgdl");
	test(dest, "ut.dfgfdsadfdsafsgdsgdgds", 40);

	strcpy(dest, "sagfdsdfdsafssgdgfdsgdsgdl");
	test(dest, "ut.dfgfdsadfdsafsgdsgdgds", 0);
}