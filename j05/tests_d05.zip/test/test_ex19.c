#include <stdio.h>
#include <assert.h>
#include <memory.h>
#include "../ex19/ft_strlcpy.c"

void test_ft_strlcpy(char *dest, char *src, unsigned int n)
{
	char *dest2 = strdup(dest);
	char *src2 = strdup(src);

	printf("dests:'%zu' dest2s:'%d'\n", strlcpy(dest, src, n), ft_strlcpy(dest2, src2, n));
	printf("dest:'%s' dest2:'%s'\n", dest, dest2);
	assert(strlcpy(dest, src, n) == ft_strlcpy(dest2, src2, n));
	assert(strcmp(dest, dest2) == 0);
}

int main() {
	test_ft_strlcpy(strdup(""), "", 1);
	test_ft_strlcpy(strdup("foobar"), "baz", 20);
	test_ft_strlcpy(strdup("cpy"), "me", 4);
	test_ft_strlcpy(strdup("cpydsafcbxcvbxcb"), "sdadfsd", 55);
	test_ft_strlcpy(strdup("cpydsafcbxcvbxcb"), "sdadfsd", 5);
	test_ft_strlcpy(strdup("cpydsaf'd    fsd"), "sdfg", 15);
	return 0;
}
