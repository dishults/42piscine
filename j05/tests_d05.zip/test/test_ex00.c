#include <stdio.h>
#include <assert.h>

int main() {
	return 0;
}
