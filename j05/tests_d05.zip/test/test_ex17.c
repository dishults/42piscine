#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <memory.h>
#include "../ex17/ft_strncat.c"

int main() {
	puts(strncat(strdup("foo"), "bar", 2));
	puts(ft_strncat(strdup("foo"), "bar", 2));
	puts(strncat(strdup("foodsfg"), "bar", 4));
	puts(ft_strncat(strdup("foosdfg"), "bar", 4));
	puts(strncat(strdup(""), "bar", 8));
	puts(ft_strncat(strdup(""), "bar", 8));
	puts(strncat(strdup(""), "bar44444", 5));
	puts(ft_strncat(strdup(""), "bar44444", 5));
}
