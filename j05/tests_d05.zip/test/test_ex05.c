#include <stdio.h>
#include <assert.h>
#include <memory.h>
#include "../ex05/ft_strstr.c"

int main(void) {
	char *str = "dsf24sdf42sdfdsfds";
	assert(strstr(str, "42") == ft_strstr(str, "42"));
	assert(strstr(str, "") == ft_strstr(str, ""));
	assert(strstr(str, "f4") == ft_strstr(str, "f4"));
	assert(strstr(str, "fds") == ft_strstr(str, "fds"));
	assert(strstr(str, "24") == ft_strstr(str, "24"));
	return 0;
}
