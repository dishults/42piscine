#include <stdio.h>
#include <memory.h>
#include "../ex09/ft_strlowcase.c"


int main() {
	puts(ft_strlowcase(strdup("SALUT, COMMENT TU VAS ? 42MOTS QUARANTE-DEUX; CINQUANTE+ET+UN")));
	return 0;
}
