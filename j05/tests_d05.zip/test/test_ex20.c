#include <unistd.h>
#include "../ex20/ft_putnbr_base.c"

void ft_putchar(char c) {
	write(1, &c, 1);
}

int main()
{
	ft_putnbr_base(5, "01");
	ft_putchar('\n');
	ft_putnbr_base(101011, "01");
	ft_putchar('\n');
	ft_putnbr_base(12340, "01234");
	ft_putchar('\n');
	ft_putnbr_base(12345, "0123456789");
	ft_putchar('\n');
	ft_putnbr_base(-12345, "0123456789");
	ft_putchar('\n');
	ft_putnbr_base(-2147483648, "0123456789");
	ft_putchar('\n');
	ft_putnbr_base(0, "0123456789abcdef");
	ft_putchar('\n');
	ft_putnbr_base(0, "0123456789");
	ft_putchar('\n');
	ft_putnbr_base(0, "0123456789");
	ft_putchar('\n');
	ft_putnbr_base(33726464, "0123456789ABCDEF");
	ft_putchar('\n');

	ft_putnbr_base(5, "011");
	ft_putchar('\n');
	ft_putnbr_base(101011, "01+");
	ft_putchar('\n');
	ft_putnbr_base(12340, "011234");
	ft_putchar('\n');
	ft_putnbr_base(12345, "01234-56789");
	ft_putchar('\n');
	ft_putnbr_base(-12345, "01234567899");
	ft_putchar('\n');
	ft_putnbr_base(-2147483648, "01234556789");
	ft_putchar('\n');
	ft_putnbr_base(-2147483648, "01234556789");
	ft_putchar('\n');
	ft_putnbr_base(-2147483648, "01234556789");
	ft_putchar('\n');
	ft_putnbr_base(-2147483648, "01234556789");
	ft_putchar('\n');
	return 0;
}
