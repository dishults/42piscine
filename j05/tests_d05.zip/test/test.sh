#!/bin/sh
mkdir -p .out
mkdir -p .log
for i in *.c; do gcc -Wall -Wextra -Werror ${i} -o .out/${i%.c}.out && .out/${i%.c}.out > .log/${i%.c}.log && echo "${i%.c} done"; done
