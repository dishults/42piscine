#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <memory.h>
#include "../ex23/ft_print_memory.c"

void ft_putchar(char c) {
	putc(c, stdout);
}

#define STRSIZE(s) (sizeof(s) - 1)

int main()
{
	char * str = "Salut les aminches c'est cool show mem on fait de truc terrible\n";
	ft_print_memory(str, sizeof("Salut les aminches c'est cool show mem on fait de truc terrible\n")+5);
	return 0;
}
