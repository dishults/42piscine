#include <stdio.h>
#include <assert.h>
#include <memory.h>
#include "../ex03/ft_strcpy.c"

void test_ft_strcpy(char *str)
{
	char dest[255];
	char dest2[255];

	strcpy(dest, str);
	ft_strcpy(dest2, str);
	assert(strcmp(dest, str) == strcmp(dest2, str));

}

int main() {
	test_ft_strcpy("");
	test_ft_strcpy("foobar");
	test_ft_strcpy("cat");
	test_ft_strcpy("catdsaf'd");
	test_ft_strcpy("catdsaf'd    fsd");
	return 0;
}
